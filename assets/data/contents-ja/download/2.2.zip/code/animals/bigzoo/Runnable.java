package animals.bigzoo;

public interface Runnable {
    void run();
}
