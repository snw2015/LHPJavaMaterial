package animals;

public class Main {
    public static void main(String[] args) {
        Cat kitty = new Cat("Kitty");
        System.out.println(kitty.name); // => Kitty
    }
}
