package animals;

public class Animal {
    String name;

    Animal(String name_) {
        name = name_;
    }
}
