package animals.constructor;

public class Animal {
    String name;

    // こちらをアンコメントしてみよう
//    Animal(String name_) {
//        name = name_;
//    }
}
