public class Truck extends Vehicle {
    double load;

    Truck(String name_, double load_) {
        super(name_);
        load = load_;
    }
}
