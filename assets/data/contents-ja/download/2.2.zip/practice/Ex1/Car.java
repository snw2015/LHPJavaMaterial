public class Car extends Vehicle{
    int seat;

    Car(String name_, int seat_) {
        super(name_);
        seat = seat_;
    }
}
