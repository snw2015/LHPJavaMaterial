public class Ex3 {
    public static void main(String[] args) {
        int x = 5;
        String[] name = {"even", "odd"};

        System.out.println("x is " + name[x % 2]);
    }
}
