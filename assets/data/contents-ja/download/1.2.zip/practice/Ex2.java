public class Ex2 {
    public static void main(String[] args) {
        int x = 7, y = 2;
        double ans = (double) x / y;

        System.out.println(x + " / " + 2 + " = " + ans);
    }
}
