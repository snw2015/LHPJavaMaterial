CREATE TABLE student (
  id      INT             PRIMARY KEY,
  name    VARCHAR(255)    NOT NULL,
  score   INT
);
