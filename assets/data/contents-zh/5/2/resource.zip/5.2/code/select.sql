-- 从表中选择所有学生的姓名和成绩
SELECT name, score FROM student;

-- 选择所有列
SELECT * FROM student;

-- 重命名输出列
SELECT name AS student_name, score AS test_score FROM student;

-- 去除重复数据
SELECT DISTINCT score FROM student;

-- 查询成绩大于 60 的学生名
SELECT name FROM student
WHERE score > 60;

-- 查询成绩在 30 到 60 之间并且名名字以 'A' 开头的学生
SELECT name FROM student
WHERE score BETWEEN 30 AND 60
AND name LIKE 'A%';

-- 查询成绩前三的学生
SELECT name, score FROM student
ORDER BY score DESC
LIMIT 3;

-- 计算最高分、最低分和平均分
SELECT MAX(score) AS highest, MIN(score) AS lowest, AVG(score) AS average
FROM student;
