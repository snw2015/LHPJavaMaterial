DROP TABLE IF EXISTS student;

-- 创建表
CREATE TABLE student (
  id    INT           PRIMARY KEY,
  name  VARCHAR(255)  NOT NULL,
  score SMALLINT      DEFAULT 0
);

-- 向表中插入一行数据
INSERT INTO student VALUES (0, 'Alice', 90);

-- 插入多行数据
INSERT INTO student VALUES
(1, 'Bob'    , 40),
(2, 'Charlie', 70);

-- 指定插入数据的列
INSERT INTO student (id, name) VALUES (3, 'Dave');

-- 指定列名时不必按照创建时的数据
INSERT INTO student (id, score, name) VALUES (4, 40, 'Ana');
