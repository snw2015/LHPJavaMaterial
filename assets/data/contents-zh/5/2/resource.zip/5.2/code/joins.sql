DROP TABLE IF EXISTS pokemon;
DROP TABLE IF EXISTS type;

-- 创建表
CREATE TABLE pokemon (
  id      INT           PRIMARY KEY,
  name    VARCHAR(255)  NOT NULL,
  type_id INT           NOT NULL
);

CREATE TABLE type (
  id        INT           PRIMARY KEY,
  name      VARCHAR(255)  NOT NULL,
  super_id  INT
);

-- 插入数据
INSERT INTO pokemon VALUES
(37 , 'Vulpix', 10),
(46 , 'Paras' , 7 ),
(133, 'Eevee' , 1 );

INSERT INTO type VALUES
(2 , 'Fight', 1 ),
(7 , 'Bug'  , 12),
(10, 'Fire' , 7 ),
(11, 'Water', 10);

-- 交叉连接
SELECT pokemon.name AS pokemon, type.name AS type
FROM pokemon, type;

-- 内连接
SELECT pokemon.name AS pokemon, type.name AS type
FROM pokemon INNER JOIN type
ON pokemon.type_id = type.id;

-- 左外连接
SELECT pokemon.name AS pokemon, type.name AS type
FROM pokemon LEFT JOIN type
ON pokemon.type_id = type.id;

-- 右外连接
SELECT pokemon.name AS pokemon, type.name AS type
FROM pokemon RIGHT JOIN type
ON pokemon.type_id = type.id;

-- 全外连接
SELECT pokemon.name AS pokemon, type.name AS type
FROM pokemon FULL JOIN type
ON pokemon.type_id = type.id;

-- 自连接
SELECT a.name AS type, b.name AS super
FROM type AS a LEFT JOIN type AS b
ON a.super_id = b.id;
