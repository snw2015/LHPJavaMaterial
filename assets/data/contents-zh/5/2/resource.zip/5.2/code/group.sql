DROP TABLE IF EXISTS employee;

-- 创建表
CREATE TABLE employee (
  id      SERIAL        PRIMARY KEY,
  name    VARCHAR(255)  NOT NULL,
  country VARCHAR(255)  NOT NULL,
  salary  NUMERIC       DEFAULT 0
);

-- 插入数据
INSERT INTO employee
(name      , country , salary) VALUES 
('Nakada'  , 'Japan' , 104.2 ),
('Charlton', 'UK'    , 78.4  ),
('Muller'  , 'German', 131.6 ),
('Nakamura', 'Japan' , 64.7  ),
('Owen'    , 'UK'    , 109.1 ),
('Sammer'  , 'German', 86.5  ),
('Kagawa'  , 'Japan' , 77.2  ),
('Law'     , 'UK'    , 43.3  );

-- 把记录按国家分组，计算每个国家的最高、最低、和平均工资
SELECT country, MAX(salary), MIN(salary), AVG(salary)
FROM  employee
GROUP BY country;

-- 把记录按国家分组，只输出平均工资大于 80 的国家
SELECT country
FROM employee
GROUP BY country
HAVING AVG(salary) > 80;
