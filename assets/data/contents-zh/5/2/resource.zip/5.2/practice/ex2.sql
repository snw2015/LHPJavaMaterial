-- 插入数据
INSERT INTO student VALUES
(0, 'Mike'    , 20, 'Python','Male'  ),
(1, 'Susan'   , 18, 'Java'  ,'Female'),
(2, 'Caroline', 20, 'Python','Female'),
(3, 'Peter'   , 21, 'Java'  ,'Male'  ),
(4, 'David'   , 22, 'Java'  ,'Male'  );

INSERT INTO subject VALUES
('AWS'        , 'Xu'     , 6, 100),
('IT Passport', 'Deng'   , 6, 100),
('Java'       , 'William', 8, 120),
('Python'     , 'Qingmei', 6, 100);
