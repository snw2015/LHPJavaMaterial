-- 查询所有男性学生的数据，按年龄从大到小排序
SELECT * FROM student
WHERE gender = 'Male'
ORDER BY age DESC;

-- 查询 Python 课和 Java 课学生分别的平均年龄
SELECT subject, AVG(age) FROM student
GROUP BY subject;

-- 根据学生的课程，查询每个学生的老师、学费和课时
SELECT student.name, subject.teacher, subject.fee, subject.hour
FROM student JOIN subject
ON student.subject = subject.name;

-- 计算每门课程的总学费
SELECT subject.name AS subject, COUNT(student.name) * subject.fee AS total_fee
FROM student RIGHT JOIN subject
ON student.subject = subject.name
GROUP BY subject.name;
