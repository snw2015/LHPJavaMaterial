public class Ex3 {
    public static void main(String[] args) {
        int x = 5;
        String[] name = {"偶数", "奇数"};

        System.out.println("x 是" + name[x % 2]);
    }
}
