package access;

public class Neighbour {
    public static void main(String[] args) {
        Parent parent = new Parent();
        parent.a = 0;
        parent.b = 0;
        parent.c = 0;
//        parent.d = 0; // error
    }
}
