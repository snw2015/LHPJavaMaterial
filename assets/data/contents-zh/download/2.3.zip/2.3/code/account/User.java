package account;

public class User {
    public String username;
    private String password;

    public int getCash() {
        return 0;
    }

    private String getPassword() {
        return password;
    }
}
