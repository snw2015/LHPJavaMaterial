package enums;

public class Player {
    private String name;
    private int x, y;

    public Player(String name) {
        this.name = name;
        x = 0;
        y = 0;
    }

    /**
     * 向某个方向移动。
     * @param direction 目标方向，是一个 Direction 枚举的值
     */
    public void move(Direction direction) {
        if (direction == Direction.STAY) {
            System.out.println(name + " stays still.");
        } else {
            System.out.println(name + " is moving " + direction + ".");
            x += direction.getDeltaX();
            y += direction.getDeltaY();
        }
    }

    /**
     * 输出当前状态。
     */
    public void printInfo() {
        System.out.println(name + " is now at (" + x + ", " + y + ").");
    }
}
