package enums;

/**
 * 存储 Player 可能移动的 9 个方向的类型。
 */
public enum Direction {
    UP          (0, -1),    // 上
    LEFT_UP     (-1, -1),   // 左上
    LEFT        (-1, 0),    // 左
    LEFT_DOWN   (-1, 1),    // 左下
    DOWN        (0, 1),     // 下
    RIGHT_DOWN  (1, 1),     // 右下
    RIGHT       (1, 0),     // 右
    RIGHT_UP    (1, -1),    // 右上
    STAY        (0, 0);     // 原地不动

    private int deltaX, deltaY; // 存储向该方向移动时，坐标的变化量

    /**
     * 方向类的构造方法，确定向该方向移动时，x 方向和 y 方向的变化量。
     * @param deltaX x 方向的变化量
     * @param deltaY y 方向的变化量
     */
    Direction(int deltaX, int deltaY) {
        this.deltaX = deltaX;
        this.deltaY = deltaY;
    }

    public int getDeltaX() {
        return deltaX;
    }

    public int getDeltaY() {
        return deltaY;
    }
}
