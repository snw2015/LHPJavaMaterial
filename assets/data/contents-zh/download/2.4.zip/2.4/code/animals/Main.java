package animals;

public class Main {
    public static void main(String[] args) {
//        Animal animal = new Animal(); // 报错，因为 Animal 是抽象类
        Cat kitty = new Cat("Kitty");
        kitty.eat("fish"); // => Kitty ate fish, meow~
    }
}
