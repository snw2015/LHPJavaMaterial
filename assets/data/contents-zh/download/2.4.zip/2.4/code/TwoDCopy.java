public class TwoDCopy {
    public static void main(String[] args) {
        int[][] a = {{1, 2}, {3, 4}};
        // 仍是浅拷贝：复制了每一个 1 维数组但每个 1 维数组仍相互关联
        int[][] b = a.clone();

        a[0][0] = 5;
        System.out.println(b[0][0]); // => 5

        // 正确的做法（深拷贝）
        for (int i = 0; i < a.length; i++) {
            a[i] = b[i].clone();
        }
        a[0][1] = 6;
        System.out.println(b[0][0]); // => 2
    }
}
