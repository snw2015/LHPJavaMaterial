package ex1;

public class Truck extends Vehicle {
    private double load;

    public Truck(String name, double load) {
        super(name);
        this.load = load;
    }

    /**
     * 默认载重 1 吨
     */
    public Truck(String name) {
        this(name, 1.0);
    }

    public double getLoad() {
        return load;
    }

    @Override
    public void print() {
        System.out.println("A truck named " + name +
                " which can load " + load + " t" +
                " is in position " + position +
                ", running at a speed of " + speed + "."
        );
    }
}
