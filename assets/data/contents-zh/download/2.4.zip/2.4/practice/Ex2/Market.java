import java.util.Random;

public class Market {
    private String name;
    private Shop[] shops;
    private Customer[] customers;

    public Market(String name, Shop[] shops, Customer[] customers) {
        this.name = name;
        this.shops = shops;
        this.customers = customers;
    }

    /**
     * 随机挑选顾客和商店进行交易。
     */
    public void tryTrade() {
        // 用于生成随机数
        Random random = new Random();

        // 随机选择一名顾客
        Customer customer = customers[random.nextInt(customers.length)];

        // 随机选择一个商店
        Shop shop = shops[random.nextInt(shops.length)];

        customer.go(shop);
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "a market with " +
                shops.length + " shops and " +
                customers.length + " customers";
    }
}
