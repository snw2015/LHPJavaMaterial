public class Catch {
    public static void main(String[] args) {
        int[] arr = new int[10];
//        System.out.println(arr[10]); // => ArrayIndexOutOfBoundsException

        try {
            System.out.println(arr[10]);
            System.out.println("Hello"); // => 这行永远不会被执行
            System.out.println(10 / 0); // => 这行将会产生一个 ArithmeticException，但这行永远不会被执行
        } catch (ArithmeticException e) {
            System.out.println("Divided by 0!");
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Index out of bound!");
        } catch (Exception e) {
            System.out.println("Unkown exception!");
            e.printStackTrace(); // 输出异常的详细信息
        }

        System.out.println("The try block is over.");
    }
}
