import java.io.File;
import java.io.IOException;

public class Throws {
    static void test() throws IOException, InterruptedException { // test 方法会掷出两种异常
        new File("?:*\"><|").createNewFile(); // 这行产生一个 IOException
        Thread.sleep(100); // 这行产生一个 InterruptedException
    }

    public static void main(String[] args) throws IOException { // IOException 被进一步掷出
        try {
            test();
        } catch (InterruptedException e) { // InterruptedException 在 try-catch 语句里被解决
            System.out.println("InterruptedException happened");
        }
    }
}
