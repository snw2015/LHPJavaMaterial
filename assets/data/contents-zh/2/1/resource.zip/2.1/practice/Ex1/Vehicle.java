public class Vehicle {
    String name;  // 名字
    double speed; // 速度

    /**
     * 移动
     */
    void move() { }

    /**
     * 加速
     */
    void speedUp(double delta) { }

    /**
     * 减速
     */
    void speedDown(double delta) { }

    /**
     * 构造方法设置名字并把速度设为 0
     */
    Vehicle(String name_) {
        name = name_;
        speed = 0;
    }

    public static void main(String[] args) {
        Vehicle car = new Vehicle("Car");
        Vehicle bike = new Vehicle("Bike");
        System.out.println(car.name); // => Car
        System.out.println(bike.speed); // => 0.0
    }
}
