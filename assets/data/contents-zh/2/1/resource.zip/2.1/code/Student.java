public class Student {
    static int studentNum = 0;
    int studentID;
    String name;

    Student(String name_) {
        name = name_;
        studentID = studentNum++; // 相当于 studentID = maxStudentID; maxStudentID++;
    }

    public static void main(String[] args) {
        Student studentA = new Student("Alice");
        Student studentB = new Student("Bob");

        System.out.println(Student.studentNum); // 使用静态变量
        System.out.println(studentNum); // 直接使用静态变量（只能在同类里）
        System.out.println(studentA.studentNum); // 通过对象名使用（不推荐）
    }
}
