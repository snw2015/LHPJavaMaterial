public class Cat {
    String name;
    int age;

    /**
     * 构造器
     */
    Cat(String name_, int age_) {
        name = name_;
        age = age_;
    }

    /**
     * 发出猫叫
     */
    void meow() {
        System.out.println("meow~");
    }

    /**
     * 吃东西
     */
    void eat(String food) {
        System.out.print(name + " ate " + food + ", ");
        meow();
    }

    public static void main(String[] args) {
        Cat alice = new Cat("Alice", 5);
        Cat bob = new Cat("Bob", 6);
        System.out.println(alice.age); // => 5

        bob.eat("catfood"); // => Bob ate cat food, meow~
    }
}
