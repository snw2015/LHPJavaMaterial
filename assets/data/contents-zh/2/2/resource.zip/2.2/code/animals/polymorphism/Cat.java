package animals.polymorphism;

public class Cat extends Animal {
    Cat(String name_) {
        super(name_);
    }

    @Override
    void eat(String food) {
        System.out.print(name + " ate " + food + ", ");
        meow(); // 猫会在进食完后喵喵叫
    }

    void meow() {
        System.out.println("meow~");
    }
}
