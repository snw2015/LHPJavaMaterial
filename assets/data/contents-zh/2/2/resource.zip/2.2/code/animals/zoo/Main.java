package animals.zoo;

public class Main {
    public static void main(String[] args) {
        // 将所有动物放入同一个数组
        Animal[] animals = {
                new Cat("Alice"),
                new Dog("Bob"),
                new Pig("Charlie"),
                new Dog("Dave")
        };

        // 不同动物进食的表现不同
        for (Animal animal : animals) {
            animal.eat("pet food");
        }
    }
}
