package animals.zoo;

public class Pig extends Animal {
    Pig(String name_) {
        super(name_);
    }

    @Override
    void eat(String food) {
        System.out.print(name + " ate " + food + ", ");
        oink(); // 猪会在进食完后噗噗叫
    }

    void oink() {
        System.out.println("oink, oink.");
    }
}
