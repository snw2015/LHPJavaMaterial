package animals.bigzoo;

public class Main {
    public static void main(String[] args) {
        // 将所有会跑的东西放在一个数组
        Runnable[] runners = {
                new Cat("Alice"),
                new Dog("Bob"),
                new Car("Volvo"),
                new Car("Toyota")
        };

        // 所有会跑的东西都跑起来
        for (Runnable runner : runners) {
            runner.run();
        }
    }
}
