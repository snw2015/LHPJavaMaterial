package animals.constructor;

// 如果去掉了 Animal 里的注释，这里会出现语法错误：Java 尝试生成 Cat 的默认构造方法，但其父类 Animal 没有无参构造方法
public class Cat extends Animal {
    void meow() {
        System.out.println("meow~");
    }
}
