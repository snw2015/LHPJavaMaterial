package animals.constructor;

public class Animal {
    String name;

    // 尝试去掉这里的注释
//    Animal(String name_) {
//        name = name_;
//    }
}
