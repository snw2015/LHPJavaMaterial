package animals.zoo;

public class Dog extends Animal {
    Dog(String name_) {
        super(name_);
    }

    @Override
    void eat(String food) {
        System.out.print(name + " ate " + food + ", ");
        bowWow(); // 狗会在进食完后汪汪叫
    }

    void bowWow() {
        System.out.println("BOWWOW!!!");
    }
}
