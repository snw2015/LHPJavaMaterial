package animals.constructor;

public class Main {
    public static void main(String[] args) {
        Cat kitty = new Cat();
        kitty.meow(); // => meow~
    }
}
