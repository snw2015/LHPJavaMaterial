package animals;

public class Cat extends Animal {
    Cat(String name_) {
        super(name_);
    }
}
