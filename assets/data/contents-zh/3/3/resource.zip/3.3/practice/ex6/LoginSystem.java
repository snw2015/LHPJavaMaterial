package ex6;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class LoginSystem {
    private final Map<String, User> users = new HashMap<>();
    private final Scanner scanner;

    public LoginSystem(Scanner scanner) {
        this.scanner = scanner;
    }

    /**
     * 用户注册功能
     */
    private void register() {
        // 首先让用户输入一次用户名和密码
        System.out.println("** Please input a username and a password to register: **");
        String username = scanner.next();
        String password = scanner.next();
        scanner.nextLine();

        while (true) {
            if (users.containsKey(username)) {
                // 如果用户名已存在，则重新输入
                System.out.println("** The username '" + username + "' has been registered. **");
            } else if (!Utils.isUsernameValid(username) || !Utils.isPasswordValid(password)) {
                // 如果用户名或密码格式不正确，则重新输入
                System.out.println("** Your input is not in right format! **");
            } else {
                // 如果格式正确，则开始输入问题和回答
                break;
            }

            // 要求用户重新输入
            System.out.println("** Please input a username and a password again: **");
            username = scanner.next();
            password = scanner.next();
            scanner.nextLine();
        }

        // 让用户输入问题和回答
        System.out.println("** Please input a question: **");
        String question = scanner.nextLine();
        System.out.println("** Please input the answer to it: **");
        String answer = scanner.nextLine();
        while (true) {
            if (question.isEmpty() || answer.isEmpty()) {
                // 如果问题或回答为空，则重新输入
                System.out.println("** The question and the answer should not be empty. **");
            } else {
                // 如果格式正确，则开始存储用户信息
                break;
            }

            // 要求用户重新输入
            System.out.println("** Please input a question and the answer again: **");
            question = scanner.next();
            answer = scanner.next();
            scanner.nextLine();
        }

        // 注册成功，输出用户列表
        users.put(username, new User(username, password, question, answer));
        System.out.println("** Register successfully! **");
        System.out.println("** User list: " + users + ". **");
    }

    /**
     * 用户登录功能
     */
    private void login() {
        // 用户输入用户名和密码
        System.out.println("** Please input the username and the password to login: **");
        String username = scanner.next();
        String password = scanner.next();
        scanner.nextLine();

        if(users.containsKey(username)) { // 如果用户名在用户表里
            if(users.get(username).getPassword().equals(password)) { // 如果密码也正确
                System.out.println("** Login successfully! Welcome, " + username + ". **");
            } else { // 如果密码不正确，开始回答问题
                System.out.println("** Wrong password. Please answer the question: **");
                System.out.println(">> Question: " + users.get(username).getQuestion() + " <<");
                String answer = scanner.nextLine();
                if (users.get(username).getAnswer().equals(answer)) {
                    // 用户回答正确，开始重设密码
                    System.out.println("** The answer is correct. Please input the new password: **");
                    password = scanner.next();
                    scanner.nextLine();

                    while (true) {
                        if (Utils.isPasswordValid(password)) {
                            // 如果密码格式正确则修改密码并结束
                            users.get(username).setPassword(password);
                            break;
                        } else {
                            // 如果密码格式不正确则重新输入密码
                            System.out.println("** Your input is not in right format! **");
                            System.out.println("** Please input the new password: **");
                            password = scanner.next();
                            scanner.nextLine();
                        }
                    }
                    System.out.println("** Change the password successfully! **");
                    System.out.println("** User list: " + users + ". **");
                } else {
                    // 用户回答错误，登录失败。
                    System.out.println("** The answer is wrong. Login failed. **");
                }
            }
        } else { // 如果用户名不在用户表里
            System.out.println("** There is no such username: '" + username + "'. Login failed. **");
        }
    }

    /**
     * 开始和用户进行交互，直到用户输入结束命令
     */
    public void start() {
        String command;

        while (true) {
            // 先让用户输入选择哪个功能
            System.out.println("** Please select an action: register or login. Type end to terminate the system. **");
            command = scanner.next();
            scanner.nextLine();
            switch (command) {
                case "register":
                    register();
                    break;
                case "login":
                    login();
                    break;
                case "end":
                    System.out.println("** Thank you for using the system. **");
                    return;
                default:
                    System.out.println("** Unknown action: '" + command + "'. **");
            }
        }
    }
}
