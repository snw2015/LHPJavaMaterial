import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Ex5 {
    static Map<String, String> users = new HashMap<>();
    static Scanner scanner;

    static boolean isUsernameValid(String username) {
        return username.matches("[a-zA-Z0-9]+");
    }

    static boolean isPasswordValid(String password) {
        return password.matches("[a-zA-Z0-9_]{8,}");
    }

    /**
     * 用户注册功能
     */
    static void register() {
        // 首先让用户输入一次用户名和密码
        System.out.println("** Please input username and password to register: **");
        String username = scanner.next();
        String password = scanner.next();
        scanner.nextLine();
        while (true) {
            if (users.containsKey(username)) {
                // 如果用户名已存在，则重新输入
                System.out.println("** The username '" + username + "' has been registered. **");
            } else if (!isUsernameValid(username) || !isPasswordValid(password)) {
                // 如果用户名或密码格式不正确，则重新输入
                System.out.println("** Your input is not in right format! **");
            } else {
                // 如果格式正确，则结束输入
                break;
            }

            // 要求用户重新输入
            System.out.println("** Please input a username and a password again: **");
            username = scanner.next();
            password = scanner.next();
            scanner.nextLine();
        }

        // 注册成功，输出用户列表
        users.put(username, password);
        System.out.println("** Register successfully! **");
        System.out.println("** User list: " + users + ". **");
    }

    /**
     * 用户登录功能
     */
    static void login() {
        // 用户输入用户名和密码
        System.out.println("** Please input a username and a password to login: **");
        String username = scanner.next();
        String password = scanner.next();
        scanner.nextLine();

        if(users.containsKey(username)) { // 如果用户名在用户表里
            if(users.get(username).equals(password)) { // 如果密码也正确
                System.out.println("** Login successfully! Welcome, " + username + ". **");
            } else { // 如果密码不正确
                System.out.println("** Wrong password. Login failed. **");
            }
        } else { // 如果用户名不在用户表里
            System.out.println("** There is no such username: '" + username + "'. Login failed. **");
        }
    }

    public static void main(String[] args) {
        scanner = new Scanner(System.in);

        String command;

        while (true) {
            // 先让用户输入选择哪个功能
            System.out.println("** Please select an action: register or login? **");
            command = scanner.next();
            scanner.nextLine();
            switch (command) {
                case "register":
                    register();
                    break;
                case "login":
                    login();
                    break;
                default:
                    System.out.println("** Unknown action: '" + command + "'. **");
            }
        }
    }
}
