import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Ex4 {
    static Map<String, String> users = new HashMap<>();

    static boolean isUsernameValid(String username) {
        return username.matches("[a-zA-Z0-9]+");
    }

    static boolean isPasswordValid(String password) {
        return password.matches("[a-zA-Z0-9_]{8,}");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String username;
        String password;

        while (true) {
            // 首先让用户输入一次用户名和密码
            System.out.println("** Please input a username and a password to register: **");
            username = scanner.next();
            password = scanner.next();
            scanner.nextLine();
            while (true) {
                if (users.containsKey(username)) {
                    // 如果用户名已存在，则重新输入
                    System.out.println("** The username '" + username + "' has been registered. **");
                } else if (!isUsernameValid(username) || !isPasswordValid(password)) {
                    // 如果用户名或密码格式不正确，则重新输入
                    System.out.println("** Your input is not in right format! **");
                } else {
                    // 如果格式正确，则结束输入
                    break;
                }

                // 要求用户重新输入
                System.out.println("** Please input a username and a password again: **");
                username = scanner.next();
                password = scanner.next();
                scanner.nextLine();
            }

            // 一次注册成功，输出用户列表，开始下一次注册
            users.put(username, password);
            System.out.println("** Register successfully! **");
            System.out.println("** User list: " + users + ". **");
        }
    }
}
