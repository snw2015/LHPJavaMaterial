import java.util.List;
import java.util.Optional;

public class OptionalTest {
    static Optional<List<String>> getList(boolean isNull) {
        return Optional.ofNullable(isNull ? null : List.of("a", "b", "c"));
    }

    public static void main(String[] args) {
        Optional<List<String>> list1 = getList(false);

        // 如果列表不为 null，则输出该列表否则，输出一个空的列表。
        System.out.println(list1.orElse(List.of()));

        // 如果列表不为 null，则输出列表的大小。
        list1.ifPresent(l -> {
            System.out.println(l.size());
        });

        System.out.println("-----");

        Optional<List<String>> list2 = getList(true);

        // 如果列表不为 null，则输出该列表否则，输出一个空的列表。
        System.out.println(list2.orElse(List.of()));

        // 如果列表不为 null，则输出列表的大小。
        list2.ifPresent(l -> {
            System.out.println(l.size());
        });
    }
}
