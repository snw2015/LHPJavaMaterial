import java.io.File;
import java.io.IOException;
import java.util.Arrays;

public class FileEx {
    public static void main(String[] args) throws IOException {
        File file = new File("a.txt"); // 创建程序目录下 a.txt 的文件对象
        if (file.exists()) { // 如果 a.txt 存在
            System.out.println(file.length()); // 输出其大小
        } else { // 如果文件不存在
            try {
                file.createNewFile(); // 创建该文件
                System.out.println(file.getAbsoluteFile()); // 输出该文件的绝对路径
            } catch (IOException e) {
                System.out.println("Failed to create the file.");
                e.printStackTrace();
            }
        }

        File dir = new File("test"); // 创建 test 文件夹的对象
        dir.mkdir(); // 创建该文件夹（如果它还不存在）

        // 在文件夹下创建两个文件
        file = new File("test/a.txt");
        file.createNewFile();

        file = new File("test/b.png");
        file.createNewFile();

        System.out.println(Arrays.toString(dir.list())); // 输出文件夹内的文件列表
    }
}
