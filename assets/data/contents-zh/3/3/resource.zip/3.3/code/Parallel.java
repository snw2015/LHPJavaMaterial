public class Parallel {
    static int count;

    public static void main(String[] args) throws InterruptedException {
        // 创建线程
        Thread t1 = new Thread(() -> {
            for (int i = 0; i < 10000; i++) {
                count++;
            }
        });
        Thread t2 = new Thread(() -> {
            for (int i = 0; i < 10000; i++) {
                count--;
            }
        });

        // 开始运行线程
        t1.start();
        t2.start();

        // 等待线程结束
        t1.join();
        t2.join();

        System.out.println(count);
    }
}
