public class MultiThread {
    public static void main(String[] args) {
        // 创建线程 1
        Thread t1 = new Thread(() -> {
            for (int i = 0; i < 10; i++) {
                System.out.println("Print in Thread 1");
                try {
                    Thread.sleep(100); // 等待 100 毫秒（0.1 秒）
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        // 创建线程 2
        Thread t2 = new Thread(() -> {
            for (int i = 0; i < 10; i++) {
                System.out.println("Print in Thread 2");
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        // 开始运行线程
        t1.start();
        t2.start();
    }
}
