import java.io.*;

public class FileIO {
    public static void main(String[] args) {
        File file = new File("a.txt"); // 选择 a.txt 文件

        try ( // 创建连接该文件的 Reader
                FileReader fileReader = new FileReader(file);
                BufferedReader reader = new BufferedReader(fileReader)
        ) {
            System.out.println(reader.lines().toList()); // 获得每一行的字符串
        } catch (FileNotFoundException e) {
            System.out.println("Cannot open file: " + file);
        } catch (IOException e) {
            System.out.println("Cannot read file: " + file);
        }

        file = new File("b.txt"); // 选择 b.txt 文件

        try ( // 创建连接该文件的 Writer
                FileWriter fileWriter = new FileWriter(file);
                BufferedWriter writer = new BufferedWriter(fileWriter)
        ) {
            // 向文件中输出字符串
            writer.write("Line 1");
            writer.newLine();
            writer.write("Line 2");
            writer.newLine();
            writer.write("Line 3");
            writer.newLine();
        } catch (FileNotFoundException e) {
            System.out.println("Cannot open file: " + file);
        } catch (IOException e) {
            System.out.println("Cannot write file: " + file);
        }
    }
}
