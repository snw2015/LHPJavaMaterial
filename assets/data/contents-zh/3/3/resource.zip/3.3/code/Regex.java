import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regex {
    public static void main(String[] args) {
        // 使用 Pattern 类判断字符串是否匹配正则表达式
        System.out.println(Pattern.matches("A[pqr]+le", "Apple"));

        // 使用 String 类的 matches 方法判断是否符合正则表达式
        String str = "Apple";
        System.out.println(str.matches("A[pqr]+le"));

        // 使用 Pattern 和 Matcher 类的方法找出所有匹配到的子串
        Matcher matcher = Pattern.compile("A[pqr]+le").matcher("Apple Abcde Appqqqrle");
        while (matcher.find()) {
            System.out.println(matcher.group());
        }
    }
}
