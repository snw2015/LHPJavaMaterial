import java.util.HashMap;
import java.util.Map;

public class Ex2 {
    public static void main(String[] args) {
        Map<String, Student> students = new HashMap<>();
        students.put("Alice", new Student("Alice", 19, 110120));
        students.put("Bob", new Student("Bob", 21, 110121));
        students.put("Carol", new Student("Carol", 20, 110122));
        students.put("Dave", new Student("Dave", 19, 110123));
        System.out.println(students);

        // 测试添加新学生
        students.put("Zoe", new Student("Zoe", 22, 110124));
        System.out.println(students);

        // 测试通过名字获取学生信息
        System.out.println(students.get("Alice"));
    }
}
