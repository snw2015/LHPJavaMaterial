import java.util.HashMap;
import java.util.Map;

public class Ex3 {
    static char mostFrequentChar(char[] arr) {
        Map<Character, Integer> times = new HashMap<>();

        // 统计每个字母的出现次数
        for (char c : arr) {
            if (times.containsKey(c)) {
                times.put(c, times.get(c) + 1);
            } else {
                times.put(c, 1);
            }
        }

        // 找到出现次数最高的字母
        char ans = 0;
        int maxTime = 0;
        for (char c : times.keySet()) {
            if (times.get(c) > maxTime) {
                maxTime = times.get(c);
                ans = c;
            }
        }
        return ans;
    }

    public static void main(String[] args) {
        System.out.println(mostFrequentChar(new char[] {'a', 'b', 'b'})); // => b
        System.out.println(mostFrequentChar(new char[] {'a', 'b', 'c', 'a'})); // => a
    }
}
