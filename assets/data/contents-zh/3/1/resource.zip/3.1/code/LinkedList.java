public class LinkedList {
    private int val;
    private boolean isHead;
    private LinkedList next;

    /**
     * 创建一个长度为 0 的新链表。
     */
    public LinkedList() {
        this.val = 0;
        this.isHead = true;
        this.next = null;
    }

    private LinkedList(int val) {
        this.val = val;
        this.isHead = false;
        this.next = null;
    }

    /**
     * 在指定节点处插入一个新节点。
     * @param index 在第几个节点处插入数据
     * @param val 新节点的数据
     */
    public void add(int index, int val) {
        if (index == 0) {
            LinkedList tmp = this.next;
            this.next = new LinkedList(val);
            this.next.next = tmp;
        } else {
            this.next.add(index - 1, val);
        }
    }

    /**
     * 删除指定节点。
     * @param index 删除第几个节点
     */
    public void remove(int index) {
        if (index == 0) {
            this.next = this.next.next;
        } else {
            this.next.remove(index - 1);
        }
    }

    /**
     * 获得指定节点的值。
     * @param index 指定节点的索引
     * @return 对应的值
     */
    public int get(int index) {
        if (index == 0) {
            return this.next.val;
        } else {
            return this.next.get(index - 1);
        }
    }


    @Override
    public String toString() {
        return isHead ?
                "Linked List {" + next + "}":
                "(" + val + ") -> " + next;
    }

    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.add(0, 2);
        list.add(1, 7);
        list.add(0, 4);
        System.out.println(list); // => Linked List {(4) -> (2) -> (7) -> null}
        System.out.println(list.get(0)); // => 4
        list.remove(1);
        System.out.println(list); // => Linked List {(4) -> (7) -> null}
    }
}
