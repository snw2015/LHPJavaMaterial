public class BinarySearch {
    /**
     * 遍历查找法。
     * @param data 要搜索的数组
     * @param val 要搜索的数据值
     * @return 该数据在数组中的索引。如果不存在则返回 -1。
     */
    public static int linearSearch(int[] data, int val) {
        for (int i = 0; i < data.length; i++) {
            System.out.print(".");
            if (data[i] == val) {
                return i;
            }
        }
        return -1;
    }

    /**
     * 二分查找法。
     * @param data 要搜索的数组
     * @param val 要搜索的数据值
     * @return 该数据在数组中的索引。如果不存在则返回 -1。
     */
    public static int binarySearch(int[] data, int val) {
        return binarySearch(data, val, 0, data.length);
    }

    private static int binarySearch(int[] data, int val, int start, int end) {
        if (start == end) { // 如果搜索长度为 0，则找不到数据
            return -1;
        }

        int middle = (start + end) / 2;

        System.out.print(".");
        if (val == data[middle]) { // 如果数组中间的数据和数据相符，找到，返回中间的坐标
            return middle;
        } else if (val < data[middle]) { // 如果比中间的数据小，搜索左边
            return binarySearch(data, val, start, middle);
        } else { // 比中间的数据大，搜索右边
            return binarySearch(data, val, middle + 1, end);
        }
    }

    public static void main(String[] args) {
        int[] data = {1, 3, 4, 7, 9, 10, 15, 19, 20, 24, 30}; // 数据从小到大排列好了
        System.out.println(linearSearch(data, 20)); // => .........8
        System.out.println(linearSearch(data, 5)); // => ...........-1
        System.out.println(binarySearch(data, 20)); // => ..8
        System.out.println(binarySearch(data, 5)); // => ....-1
    }
}
