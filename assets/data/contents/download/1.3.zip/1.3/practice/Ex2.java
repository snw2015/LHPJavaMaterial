public class Ex2 {
    public static void main(String[] args) {
        int x = 5;
        boolean isPrime = true;

        // 比 2 小的一定不是素数
        if (x < 2) {
            isPrime = false;
        }

        // 判断 x 是否为素数
        for (int i = 2; i < x; i++) {
            if (x % i == 0) { // 如果 x 整除 i
                isPrime = false; // x 不是素数
                break; // 剩下的 i 也不用判断了
            }
        }

        // 输出
        if (isPrime) {
            System.out.println(x + " 是素数");
        } else {
            System.out.println(x + " 不是素数");
        }
    }
}
