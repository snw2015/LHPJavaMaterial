public class Ex1 {
    public static void main(String[] args) {
        int month = 7;

        switch (month) {
            case 3, 4, 5: // 这种语法只能在 Java 14 后的版本中使用
                System.out.println("春季");
                break;
            case 6, 7, 8:
                System.out.println("夏季");
                break;
            case 9, 10, 11:
                System.out.println("秋季");
                break;
            case 12, 1, 2:
                System.out.println("冬季");
                break;
        }
    }
}
