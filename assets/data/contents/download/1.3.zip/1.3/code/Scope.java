public class Scope {
    public static void main(String[] args) {

        // x = 0; // 无法使用 x，报错

        // 以下代码被放入代码块中
        {

            // x = 0; // 无法使用 x，报错

            int x = 100;

            x = 0; // 可以使用 x
            System.out.println(x); // => 0

        } // 代码块结束

        // x = 0; // 无法使用 x，报错
    }
}
