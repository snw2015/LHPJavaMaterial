public class Label {
    public static void main(String[] args) {
        // 不使用标签（label）
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.println(i + ", " + j);
                if (j == 2) {
                    break;
                }
            }
        }

        System.out.println("-----");

        // 使用标签（label）
        outer: for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.println(i + ", " + j);
                if (j == 2) {
                    break outer;
                }
            }
        }
    }
}
