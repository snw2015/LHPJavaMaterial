import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import org.postgresql.Driver;

public class TransanctionExample {
    public static void main(String[] args) {
        // 没有使用事务
//        noTransaction();
        // 使用事务
        useTransaction();
    }
    
    /**
     * 没有使用事务的方法。注意运行后数据库的变化。
     */
    public static void noTransaction() {
        String sql1 = "INSERT INTO account VALUES(?, ?)";
        String sql2 = "UPDATE account SET password=? WHERE username=?";
        String sql3 = "DELETE FROM account WHERE username=?";
        
        Driver driver = new Driver();
        String propertyPath = "jdbc.properties";

        Properties properties = new Properties();
        try {
            properties.load(new FileReader(propertyPath));
        } catch (IOException e) {
            System.err.println("Failed to read the property file: " + propertyPath + ".");
            e.printStackTrace();
            return;
        }

        String url = properties.getProperty("url");
        Properties info = new Properties();
        info.setProperty("user", properties.getProperty("user"));
        info.setProperty("password", properties.getProperty("password"));
        
        try (
                Connection con = driver.connect(url, info);
                PreparedStatement smt1 = con.prepareStatement(sql1);
                PreparedStatement smt2 = con.prepareStatement(sql2);
                PreparedStatement smt3 = con.prepareStatement(sql3);
        ) {

            // 执行第 1 条 SQL 插入数据
            smt1.setString(1,"Ana");
            smt1.setString(2,"123");
            smt1.executeUpdate(); 
            
            int i = 1 / 0; // 抛出异常，但第 1 条语句执行完成后已被自动提交至数据库。
            
            // 执行第 2 条 SQL 修改数据
            smt2.setString(1,"123456");
            smt2.setString(2,"Ana");
            smt2.executeUpdate(); 
            
            // 执行第 3 条 SQL 删除数据
            smt3.setString(1,"Alice");
            smt3.executeUpdate(); 

        } catch (Exception e) { // 处理数据库操作时出现的异常
            System.err.println("Error happened when I try to access the database: " 
                    + properties.getProperty("url") + ".");
            e.printStackTrace();
        }
    }

    /**
     * 使用事务的方法。注意运行后数据库的变化。
     */
    public static void useTransaction() {
        String sql1 = "INSERT INTO account VALUES(?, ?)";
        String sql2 = "UPDATE account SET password=? WHERE username=?";
        String sql3 = "DELETE FROM account WHERE username=?";
        
        Driver driver = new Driver();
        String propertyPath = "jdbc.properties";

        Properties properties = new Properties();
        try {
            properties.load(new FileReader(propertyPath));
        } catch (IOException e) {
            System.err.println("Failed to read the property file: " + propertyPath + ".");
            e.printStackTrace();
            return;
        }

        String url = properties.getProperty("url");
        Properties info = new Properties();
        info.setProperty("user", properties.getProperty("user"));
        info.setProperty("password", properties.getProperty("password"));
        
        try (
                Connection con = driver.connect(url, info);
                PreparedStatement smt1 = con.prepareStatement(sql1);
                PreparedStatement smt2 = con.prepareStatement(sql2);
                PreparedStatement smt3 = con.prepareStatement(sql3);
        ) {
            con.setAutoCommit(false); // 关闭自动提交

            try {
                // 执行第 1 条 SQL 插入数据
                smt1.setString(1,"Ana");
                smt1.setString(2,"123");
                smt1.executeUpdate(); 
                
                int i = 1 / 0; // 抛出异常，但第 1 条语句未被提交至数据库。
                
                // 执行第 2 条 SQL 修改数据
                smt2.setString(1,"123456");
                smt2.setString(2,"Ana");
                smt2.executeUpdate(); 
                
                // 执行第 3 条 SQL 删除数据
                smt3.setString(1,"Alice");
                smt3.executeUpdate();
                
                // 在全部语句完成后，再作为事务提交
                con.commit();
                
            } catch (Exception e) { // 处理数据操作时出现的异常
                System.err.println("Error happened when I try to update the database: " 
                        + properties.getProperty("url") + ".");
                e.printStackTrace();
                con.rollback();
                System.out.println("I have rolled back the queries.");
            }
        } catch (SQLException e) { // 处理数据库连接时出现的异常
            System.err.println("Error happened when I try to access the database: " 
                    + properties.getProperty("url") + ".");
            e.printStackTrace();
        }
    }
}
