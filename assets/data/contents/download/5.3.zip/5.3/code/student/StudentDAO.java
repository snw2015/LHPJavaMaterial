package student;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.postgresql.Driver;

public class StudentDAO {
    private static final String PROPERTY_PATH = "dao.properties";
    private static final Driver DRIVER = new Driver();
    
    private String url = "";
    private String user = "";
    private String password = "";

    private Connection con = null; // 与数据库的链接
    
    public StudentDAO() {
        // 读入配置文件
        Properties properties = new Properties();
        try {
            properties.load(new FileReader(PROPERTY_PATH));
        } catch (IOException e) {
            System.err.println("Failed to read the property file: " + PROPERTY_PATH + ".");
            e.printStackTrace();
            return;
        }
        
        url = properties.getProperty("url");
        user = properties.getProperty("user");
        password = properties.getProperty("password");

        // 建立链接
        Properties info = new Properties();
        info.setProperty("user", user);
        info.setProperty("password", password);

        try {
            con = DRIVER.connect(url, info);
        } catch (SQLException e) { // 处理连接数据库时出现的异常
            System.err.println("Error happened when I try to connect to the database: " + url + ".");
            e.printStackTrace();
        }
    }

    /**
     * 访问数据库的 student 表，并获得所有学生数据的列表。
     */
    public List<StudentDTO> findAll() {
        List<StudentDTO> result = new ArrayList<>();
        
        String sql = "SELECT * FROM student";
        
        try (Statement smt = con.createStatement()) {
            ResultSet rs = smt.executeQuery(sql);
            
            // 通过数据库查询到的数据，创建学生对象，并放入列表
            while (rs.next()) {
                result.add(new StudentDTO(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getString("subject"),
                        rs.getString("gender")
                ));
            }
            
        } catch (SQLException e) { // 处理数据库操作时出现的异常
            System.err.println("Error happened when I try to get students' data.");
            e.printStackTrace();
        }
        
        return result;
    }

    /**
     * 存储一个学生的数据至 student 表。
     */
    public int save(StudentDTO student) {        
        String sql = "INSERT INTO student VALUES (?, ?, ?, ?, ?)";
        int result = 0;
        
        try (PreparedStatement smt = con.prepareStatement(sql)) {
            // 使用学生对象设置参数
            smt.setInt(1, student.getId());
            smt.setString(2, student.getName());
            smt.setInt(3, student.getAge());
            smt.setString(4, student.getSubject());
            smt.setString(5, student.getGender());
            
            result = smt.executeUpdate();
            
        } catch (SQLException e) { // 处理数据库操作时出现的异常
            System.err.println("Error happened when I try to save the student: " + student + ".");
            e.printStackTrace();
        }
        
        return result;
    }
    
    /**
     * 在使用完后释放资源。
     */
    public void close() {
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println("Error happened when I try to close the connection: " + url + ".");
                e.printStackTrace();
            }
        }
    }
}
