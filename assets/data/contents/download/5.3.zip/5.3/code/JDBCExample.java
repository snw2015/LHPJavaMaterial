import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.postgresql.Driver;

public class JDBCExample {
    public static void main(String[] args) throws Exception {
        test1();
//      test2();
    }
    
    /**
     * 基本的连接方法，没有处理异常。
     */
    public static void test1() throws Exception {
        // 1. 注册驱动，创建 Driver 对象
        Driver driver = new Driver();

        // 2. 取得数据库链接（第一种方法：直接在代码里输入配置）
        String url = "jdbc:postgresql://localhost:5432/hello"; // 设定数据库地址
        Properties info = new Properties();
        info.setProperty("user", "postgres"); // 设定用户名
        info.setProperty("password", "123456"); // 设定密码

        Connection con = driver.connect(url, info); // 建立链接

        // 2. 取得数据库链接（第二种方法：使用 Properties 文件输入配置）
//        Properties properties = new Properties(); // 存储配置信息的 Properties 对象
//        properties.load(new FileReader("hello.properties"));
//        
//        String url = properties.getProperty("url"); // 设定数据库地址
//        Properties info = new Properties();
//        info.setProperty("user", properties.getProperty("user")); // 设定用户名
//        info.setProperty("password", properties.getProperty("password")); // 设定密码
//        
//        Connection connect = driver.connect(url, info); // 建立链接

        // 3. 执行 SQL 语句
        Statement smt = con.createStatement();

        String sql = "SELECT * FROM student";

        ResultSet rs = smt.executeQuery(sql); // 获得查询结果集

        // 输出全部查询结果的 id、name 和 score
        while (rs.next()) {
            System.out.println("[id: " + rs.getInt("id") + ", name: " + rs.getString("name") + ", score: "
                    + rs.getInt("score") + "]");
        }

        // 4. 关闭连接资源
        smt.close();
        con.close();
    }

    /**
     * 使用 try-with-resources 语句添加了对异常的应对。
     */
    public static void test2() {
        // 1. 注册驱动，创建 Driver 对象
        Driver driver = new Driver();
        String propertyPath = "hello.properties";

        // 2. 取得数据库链接
        Properties properties = new Properties(); // 存储配置信息的 Properties 对象
        try {
            properties.load(new FileReader(propertyPath));
        } catch (IOException e) { // 处理读取配置文件时出现的异常
            System.err.println("Failed to read the property file: " + propertyPath);
            e.printStackTrace();
            return;
        }

        String url = properties.getProperty("url"); // 设定数据库地址
        Properties info = new Properties();
        info.setProperty("user", properties.getProperty("user")); // 设定用户名
        info.setProperty("password", properties.getProperty("password")); // 设定密码

        try (
                Connection con = driver.connect(url, info);
                Statement smt = con.createStatement();
        ) {
            // 3. 执行 SQL 语句
            String sql = "SELECT * FROM student";

            ResultSet rs = smt.executeQuery(sql); // 获得查询结果集

            // 输出全部查询结果的 id、name 和 score
            while (rs.next()) {
                System.out.println("[id: " + rs.getInt("id") + ", name: " + rs.getString("name") + ", score: "
                        + rs.getInt("score") + "]");
            }

        } catch (SQLException e) { // 处理数据库操作时出现的异常
            System.err.println("Error happened when I try to access the database: " 
                    + properties.getProperty("url") + ".");
            e.printStackTrace();
        }
    }
}
