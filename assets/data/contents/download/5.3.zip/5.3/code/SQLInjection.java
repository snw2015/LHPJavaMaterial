import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.postgresql.Driver;

public class SQLInjection {
    public static void main(String[] args) {
        test1("Alice");
        test1("Dave");
        // SQL 注入
//        test1("'; UPDATE account SET password = 'HACKED' --");

//        test2("Alice");
//        test2("Dave");
        // SQL 注入
//        test2("'; UPDATE account SET password = 'HACKED' --");
    }
    
    /**
     * 使用普通的 Statement 无法避免 SQL 注入风险。
     */
    public static void test1(String username) {
        Driver driver = new Driver();
        String propertyPath = "jdbc.properties";

        Properties properties = new Properties();
        try {
            properties.load(new FileReader(propertyPath));
        } catch (IOException e) {
            System.err.println("Failed to read the property file: " + propertyPath);
            e.printStackTrace();
            return;
        }

        String url = properties.getProperty("url");
        Properties info = new Properties();
        info.setProperty("user", properties.getProperty("user"));
        info.setProperty("password", properties.getProperty("password"));

        String sql = "SELECT password FROM account WHERE username = '" + username + "'";
        
        try (
                Connection con = driver.connect(url, info);
                Statement smt = con.createStatement();
        ) {

            ResultSet rs = smt.executeQuery(sql);

            if (rs.next()) {
                System.out.println("The password of " + username + " is '" + rs.getString("password") + "'.");
            } else {
                System.out.println("There is no user called '" + username + "'.");
            }

        } catch (SQLException e) { // 处理数据库操作时出现的异常
            System.err.println("Error happened when I try to access the database: " + properties.getProperty("url"));
            e.printStackTrace();
        }
    }
    
    /**
     * 使用 PreparedStatement 避免 SQL 注入风险。
     */
    public static void test2(String username) {
        Driver driver = new Driver();
        String propertyPath = "jdbc.properties";

        Properties properties = new Properties();
        try {
            properties.load(new FileReader(propertyPath));
        } catch (IOException e) {
            System.err.println("Failed to read the property file: " + propertyPath);
            e.printStackTrace();
            return;
        }

        String url = properties.getProperty("url");
        Properties info = new Properties();
        info.setProperty("user", properties.getProperty("user"));
        info.setProperty("password", properties.getProperty("password"));

        String sql = "SELECT password FROM account WHERE username = ?"; // 准备 SQL 语句的 “模板”
        
        try (
                Connection con = driver.connect(url, info);
                PreparedStatement smt = con.prepareStatement(sql);
        ) {
            smt.setString(1, username); // 将语句中的第一个 “?” 设为用户名的字符串

            ResultSet rs = smt.executeQuery();

            if (rs.next()) {
                System.out.println("The password of " + username + " is '" + rs.getString("password") + "'.");
            } else {
                System.out.println("There is no user called '" + username + "'.");
            }

        } catch (SQLException e) { // 处理数据库操作时出现的异常
            System.err.println("Error happened when I try to access the database: " + properties.getProperty("url"));
            e.printStackTrace();
        }
    }
}
