package login;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

import org.postgresql.Driver;

public class AccountRepositoryImpl implements AccountRepository {
    private static final String PROPERTY_PATH = "jdbc.properties";
    private static final Driver DRIVER = new Driver();
    
    private String url = "";
    private String user = "";
    private String password = "";

    private Connection con = null; // 与数据库的链接
    
    public AccountRepositoryImpl() {
        // 读入配置文件
        Properties properties = new Properties();
        try {
            properties.load(new FileReader(PROPERTY_PATH));
        } catch (IOException e) {
            System.err.println("Failed to read the property file: " + PROPERTY_PATH + ".");
            e.printStackTrace();
            return;
        }
        
        url = properties.getProperty("url");
        user = properties.getProperty("user");
        password = properties.getProperty("password");

        // 建立链接
        Properties info = new Properties();
        info.setProperty("user", user);
        info.setProperty("password", password);

        try {
            con = DRIVER.connect(url, info);
        } catch (SQLException e) { // 处理连接数据库时出现的异常
            System.err.println("Error happened when I try to connect to the database: " + url + ".");
            e.printStackTrace();
        }
    }

    /**
     * 访问数据库的 account 表，并获得所有账号数据的列表。
     */
    public List<Account> findAll() {
        List<Account> result = new ArrayList<>();
        
        String sql = "SELECT * FROM account";
        
        try (Statement smt = con.createStatement()) {
            ResultSet rs = smt.executeQuery(sql);
            
            // 通过数据库查询到的数据，创建账号对象，并放入列表
            while (rs.next()) {
                result.add(new Account(
                        rs.getString("username"),
                        rs.getString("password")
                ));
            }
            
        } catch (SQLException e) { // 处理数据库操作时出现的异常
            System.err.println("Error happened when I try to get accounts' data.");
            e.printStackTrace();
        }
        
        return result;
    }
    
    /**
     * 访问数据库的 account 表，并获得所有账号数据的列表。
     */
    public Optional<Account> findAccountByUsername(String username) {
        String sql = "SELECT * FROM account WHERE username = ?";
        Account result = null;
        
        try (PreparedStatement smt = con.prepareStatement(sql)) {
            smt.setString(1, username);
            
            ResultSet rs = smt.executeQuery();
            
            // 数据库查询到相应数据，则创建账号对象
            if (rs.next()) {
                result = new Account(
                        rs.getString("username"),
                        rs.getString("password")
                );
            }
            
        } catch (SQLException e) { // 处理数据库操作时出现的异常
            System.err.println("Error happened when I try to get " + username +  "'s data.");
            e.printStackTrace();
        }
        
        // 因为返回值可能为空（不存在对应账号），这里使用 Optional 类方便处理。
        return Optional.ofNullable(result);
    }

    /**
     * 访问数据库的 account 表，并获得所有学生数据的列表。
     */
    public int save(Account account) {        
        String sql = "INSERT INTO account VALUES (?, ?)";
        int result = 0;
        
        try (PreparedStatement smt = con.prepareStatement(sql)) {
            // 使用接收到的账号对象设置参数
            smt.setString(1, account.getUsername());
            smt.setString(2, account.getPassword());

            result = smt.executeUpdate();
            
        } catch (SQLException e) { // 处理数据库操作时出现的异常
            System.err.println("Error happened when I try to save the account: " + account + ".");
            e.printStackTrace();
        }
        
        return result;
    }
    
    /**
     * 在使用完后释放资源。
     */
    public void close() {
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println("Error happened when I try to close the connection: " + url + ".");
                e.printStackTrace();
            }
        }
    }
}
